<h1>Voeg een medewerker toe</h1>
<form name="create" method="post" action="create">
	<!-- bouw hier je formulier -->
</form>