	
	<h1>Persoon wijzigen</h1>
	<form name="update" method="post" action="<?=URL?>employee/update">
	    <input type="hidden" name="id" value="<?=$employee["id"] ?>"/>
	    <!--  Bouw hier de rest van je formulier   -->
	</form>