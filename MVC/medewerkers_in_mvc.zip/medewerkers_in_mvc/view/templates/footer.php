<footer>&copy; Jouw Naam</footer>
</div><!-- end container div -->
</body>
</html>